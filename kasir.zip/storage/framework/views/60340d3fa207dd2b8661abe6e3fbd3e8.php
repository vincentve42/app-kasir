<html>
    <head>

        <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
      <script src="https://cdn.jsdelivr.net/npm/apexcharts@3.46.0/dist/apexcharts.min.js"></script>
      <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>
    </head>
        <body x-data="{open : false}">
            
        
      <div class="flex sm:hidden justify-between items-center justify-items-center" >
      <div>
        <button @click="open = !open">
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" class="size-10 pl-2">
        <path strokeLinecap="round" strokeLinejoin="round" d="M3.75 6.75h16.5M3.75 12h16.5m-16.5 5.25h16.5" />
        </svg>
        </button>
      </div>
      <div>
         <?php if(session('cart')): ?>
         
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-6 text-black">
  <path stroke-linecap="round" stroke-linejoin="round" d="M15.75 10.5V6a3.75 3.75 0 1 0-7.5 0v4.5m11.356-1.993 1.263 12c.07.665-.45 1.243-1.119 1.243H4.25a1.125 1.125 0 0 1-1.12-1.243l1.264-12A1.125 1.125 0 0 1 5.513 7.5h12.974c.576 0 1.059.435 1.119 1.007ZM8.625 10.5a.375.375 0 1 1-.75 0 .375.375 0 0 1 .75 0Zm7.5 0a.375.375 0 1 1-.75 0 .375.375 0 0 1 .75 0Z" />
</svg>
          <?php else: ?>
          <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-6 ">
  <path stroke-linecap="round" stroke-linejoin="round" d="M15.75 10.5V6a3.75 3.75 0 1 0-7.5 0v4.5m11.356-1.993 1.263 12c.07.665-.45 1.243-1.119 1.243H4.25a1.125 1.125 0 0 1-1.12-1.243l1.264-12A1.125 1.125 0 0 1 5.513 7.5h12.974c.576 0 1.059.435 1.119 1.007ZM8.625 10.5a.375.375 0 1 1-.75 0 .375.375 0 0 1 .75 0Zm7.5 0a.375.375 0 1 1-.75 0 .375.375 0 0 1 .75 0Z" />
</svg>
<?php endif; ?>
        

      </div>
    </div>
      <div class="" x-show="open">
            <ul>
                <a href="<?php echo e(route('Dashboard')); ?>"><li class="pt-2 pl-3 border-b border-gray-300">Dashboard</li></a>
                <a href="<?php echo e(route('ProductUi')); ?>"><li class="pt-2 pl-3 border-b border-gray-300">Product</li></a>
                <a href="<?php echo e(route('SalesUi')); ?>"><li class="pt-2 pl-3 border-b border-gray-300">Sales</li></a>
                <a href="<?php echo e(route('CashierUi')); ?>"><li class="pt-2 pl-3 border-b border-gray-300">Kasir</li></a>
                
            </ul>
      </div>
      <div class="fixed pt-8 top-0 left-0 z-40 w-64 h-screen transition-transform -translate-x-full sm:translate-x-0 bg-gray-50">
    
        <ul>
          <li class="text-2xl justify-self-center font-bold">AkuKasir.com</li>
          <a href="<?php echo e(route('Dashboard')); ?>"><li class="justify-self-center pt-3"><img src="<?php echo e(asset("asset/logo.png")); ?>" alt="" class="w-32"></li></a>
          <a href="<?php echo e(route('Dashboard')); ?>"><li class="pl-10 pt-5 text-xl font-bold">Dashboard</li></a>
          <a href="<?php echo e(route('ProductUi')); ?>"><li class="pl-10 pt-5 text-xl font-bold">Product</li></a>
          <a href="<?php echo e(route('SalesUi')); ?>"><li class="pl-10 pt-5 text-xl font-bold">Sales</li></a>
          <a href="<?php echo e(route('CashierUi')); ?>"><li class="pl-10 pt-5 text-xl font-bold">Kasir</li></a>
          
        </ul>
      </div>
      
        <div class="sm:mt-10 sm:ml-70 sm:w-390 sm:h-200 w-145 h-64 mt-3 ml-5 shadow-xl">
            <form action="<?php echo e(route('DeleteProduct', ['id' => $selected_product->id ])); ?>" method="post">
                <?php echo csrf_field(); ?>
            <h1 class="justify-self-center md:text-4xl font-bold text-2xl">Delete Product</h1>
            <h1 class="justify-self-center md:pt-10 pt-5 md:text-2xl text-base">Anda yakin untuk menghapus produk <?php echo e($selected_product->judul); ?></h1>
            <input type="hidden" name="id" value="<?php echo e($selected_product->id); ?>">
            <div class="flex justify-center">
                <div class="md:p-5 p-5">
                    <button type="submit" class="rounded-4xl text-green-500 border border-green-400 text-2xl p-3 w-32">Ya</button>
                </div>
                <div class="md:p-5 p-5">
                     <button class="rounded-4xl text-red-500 border border-red-400 text-2xl p-3 w-32">Tidak</button>
                </div>
            </div>
        </form>
        </div>
   
   </body>
</html><?php /**PATH G:\website\kasir\resources\views/dashboard/delete-product.blade.php ENDPATH**/ ?>